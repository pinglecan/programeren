#constants
JOURNEY_IN_DAYS = 0

#data
mainCharacter = {
    'name' : 'Pingle',
    'ownsHorse' : True,
    'adventuring' : True,
    'cash' : {
        'platinum' : 0,
        'gold' : 1,
        'silver' : 7,
        'copper' : 5
    }
}

friends = []

adventurerGear = []

investors = []

treasure = []